import React from "react";

function BookDetails() {
  return (
    <div>
      <h2>Book Details</h2>
      <p>Title: React in Action</p>
      <p>Author: Mark Tielens Thomas</p>
      <p>Price: ₹799</p>
    </div>
  );
}

export default BookDetails;
