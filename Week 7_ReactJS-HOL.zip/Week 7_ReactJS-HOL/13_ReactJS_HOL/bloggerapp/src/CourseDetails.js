import React from "react";

function CourseDetails() {
  return (
    <div>
      <h2>Course Details</h2>
      <p>Course: React Fundamentals</p>
      <p>Duration: 6 Weeks</p>
    </div>
  );
}

export default CourseDetails;
